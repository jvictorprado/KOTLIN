import kotlin.browser.*
import org.w3c.dom.*

fun main(){
  println("Hello world!")
}